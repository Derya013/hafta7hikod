package com.example.hikod_hafta7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
